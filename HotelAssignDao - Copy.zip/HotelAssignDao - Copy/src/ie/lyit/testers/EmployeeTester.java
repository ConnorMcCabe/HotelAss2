package ie.lyit.testers;

import ie.lyit.hotel.Employee;
import ie.lyit.hotel.Name;
import ie.lyit.hotel.Date;
public class EmployeeTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Create Employee A
		Employee employeeA = new Employee();
		
		//display employee A's details
		System.out.println(employeeA);
		
		//Set Employee A's details
		employeeA.setName(new Name("Mr.", "Homer", "Simpson"));
		employeeA.setAddress(" 67 Meadow, Cong, Co. Mayo");
		employeeA.setPhoneNumber(" 087 1234567");
		employeeA.setDOB(new Date(25, 12, 1952));
		employeeA.setStartDate(new Date(12, 2, 1999));
		employeeA.setSalary(60000);
		
		System.out.println(employeeA);
		
		
	}
	
	
	
	

}
