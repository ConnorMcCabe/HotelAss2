package ie.lyit.testers;

import ie.lyit.hotel.Name;
import java.util.ArrayList;
public class NameTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Create a name object called personA
	Name personA = new Name();
	//display personA's details on screen
	System.out.println(personA);
	
	//set PersonA's name
	personA.setTitle("Mr.");
	personA.setFirstName("Homer");
	personA.setSurname("Simpson");
	
	//display person's details
	System.out.println(personA);

	//Create details for personB
	Name personB = new Name("Mrs", "Marge", "Simpson");
	
	//display personB's details
	System.out.println(personB);
	
	if(personA.equals(personB))
			System.out.println(personA + " is the same as "+personB);
	else
			System.out.println(personA + "is not the same as "+personB);
	
	if(personB.isFemale())
		System.out.print(personB + " is female " );
	else
		System.out.println(personB + "is not female");
	
	ArrayList<Name> names = new ArrayList<Name>();
	names.add(new Name("Mr.", "Bart", "Simpson"));
	names.add(personA);
	names.add(personB);
	names.trimToSize();

	for(Name tempName:names )
	System.out.println(tempName);
	
	if(nameSearch(personA, names))
		System.out.println("FOUND!");
	else
		System.out.println("NOT FOUND!");
	
	}
	public static boolean nameSearch(Name nameSearch, ArrayList<Name> listOfNames){
		for (Name currentName:listOfNames){
			if(currentName.equals(nameSearch))
				return true;
		}
		return false;
		}

}
