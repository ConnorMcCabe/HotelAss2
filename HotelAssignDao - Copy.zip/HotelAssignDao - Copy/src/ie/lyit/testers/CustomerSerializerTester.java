//----------------------------------------------------------------------------------|
// Connor McCabe - L00114966													//	|
// Computer Security and Digital Forensics										//	|
//Software Implementation Assignment 1 for Maria Boyle							//	|
// 15/11/17																		//	|
package ie.lyit.testers;														//	|							
import java.util.Scanner;														//	|															
import ie.lyit.hotel.*;															//	|
import ie.lyit.serialize.*;									//	|
//----------------------------------------------------------------------------------|
public class CustomerSerializerTester {											//	|
//----------------------------------------------------------------------------------|
public static void main(String [] args)											//	|
{																				//	|
	Menu newMenu = new Menu();													//	|
	//CustomerSerializer customerSerializer = new CustomerSerializer();			//	|
	//customerSerializer.readRecordsFromFile();			
	
	final CustomerFactory factory = new CustomerFactory();
																				//	|
	int option; 																//	|
	Scanner keyIn = new Scanner(System.in);										//	|
																				//	|
	do{																			//	|
		newMenu.display();														//	|
		newMenu.readOption();													//	|
																				//	|
			switch(newMenu.getOption())											//	|
			{																	//	|
			case 1:factory.createCustomerAndStore(); break;								//	|
			case 2:factory.list(); System.out.println(); break;		//	|
			case 3:factory.view(); break;							//	|
			case 4:factory.edit(); break;							//	|
			case 5:factory.delete();									//	|
			case 6:break;														//	|
			}																	//	|
	}																			//	|
	while(newMenu.getOption() != 6);											//	|
																				//	|
	//customerSerializer.writeRecordsToFile();									//	|
	}																			//	|
}																				//	|
//----------------------------------------------------------------------------------|