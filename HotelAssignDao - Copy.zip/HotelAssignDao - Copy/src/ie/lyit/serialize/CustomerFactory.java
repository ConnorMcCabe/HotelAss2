package ie.lyit.serialize;
import java.util.ArrayList;
import java.util.Scanner;
import ie.lyit.hotel.*;
import java.io.*;

public class CustomerFactory extends DataAccessCust implements Serializable{

	private static ArrayList<Customer> customers = new ArrayList<>();
	
			static
			{
				customers = new DataAccessCust().read();
				if(customers == null)
					customers = new ArrayList<>();
				//else
					//Customer.setCustomerNumberLength(customers.size());
				
				System.out.println("CustomersFactory");
			}
																																						
			public static Customer read(){																		//	|
				//	|
				Customer customers = new Customer();															//	|
				Scanner readIn = new Scanner(System.in);														//	|	
				Name name = new Name();																			//	|
				//	|
				//...From here prompt user to enter in....														//	|
				System.out.println("Enter Customer Details\n");													//	|
				//...Customer title...																			//	|
				System.out.println("Enter Title:");																//	|
				//...receiving input...																			//	|
				name.setTitle(readIn.nextLine());																//	|
				//	|
				//...Customer First Name...																		//	|
				System.out.println("Enter First Name");															//	|
				//...receiving input...																			//	|
				name.setFirstName(readIn.nextLine());															//	|
				//	|
				//...Customer Surname...																		//	|
				System.out.println("Enter Surname:");															//	|
				//...receiving input...																			//	|
				name.setSurname(readIn.nextLine());																//	|
				//	|
				//...All details entered so far are saved as customer's name so all will display when called...	//	|
				customers.setName(name);																		//	|
				//	|
				//...Customer Email...																			//	|
				System.out.println("Enter Email Address:");														//	|
				//...receiving input...																			//	|
				customers.setEmailAddress(readIn.nextLine());													//	|
				//	|
				//...Customer Phone Number...																	//	|
				System.out.println("Enter Phone Number: ");														//	|
				//...receiving input...																			//	|
				customers.setPhoneNumber(readIn.nextLine());													//	|
				//	|
				//...Customer Home Address...																	//	|
				System.out.println("Enter Address: ");															//	|
				//...receiving input...																			//	|
				customers.setAddress(readIn.nextLine());														//	|
				//	|
				//...resumes...																					//	|
				return customers; 							
	
	public void createCustomerAndStore()
	{
		
		customers.add(createCustomer());
		storeCustomers();
	
	}
	
	public static void GetCustomer()
	{
		return 0=0;
	}
	}

	public static void storeCustomers()
	{
		new DataAccessCust().write(customers);
	}
	
	public static ArrayList<Customer> getCustomers()
	{
		return (ArrayList<Customer>)customers.clone();
	}

	public static void remove(Customer toSelect)
	{
		customers.remove(toSelect);
	}
	
	public static void edit(Customer toSelect)
	{
		if(toSelect != null)
		{
			int index = customers.indexOf(toSelect);
			toSelect = (Customer) createCustomer();
				customers.set(index,  toSelect);
				storeCustomers;
		}
	}
			
	
}














