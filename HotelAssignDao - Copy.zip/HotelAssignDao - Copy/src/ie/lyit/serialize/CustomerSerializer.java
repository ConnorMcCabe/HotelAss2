////------------------------------------------------------------------------------------------|
//// Connor McCabe - L00114966															//	|
//// Computer Security and Digital Forensics												//	|
////Software Implementation Assignment 1 for Maria Boyle									//	|
//// 15/11/17																				//	|
//package ie.lyit.serialize;																//	|
//import java.util.Scanner;																//	|
//import java.util.ArrayList;																//	|
//import java.io.*;																		//	|
//import ie.lyit.hotel.Customer;															//	|
////------------------------------------------------------------------------------------------|
//public class CustomerSerializer extends Customer implements Serializable{				//	|
//		//Defining customers array														//	|
//		private ArrayList<Customer> customers;											//	|
//		//Defining file to save customer details										//	|
//		//private final String FILENAME = "customers.txt";								//	|
////------------------------------------------------------------------------------------------|
//		// Default Constructor															//	|
//		public CustomerSerializer()														//	|
//		{																				//	|
//			customers = new ArrayList<Customer>();										//	|
//		}																				//	|
////------------------------------------------------------------------------------------------|
//		//Method to add customer														//	|
////		public void add()																//	|
////		{	//Calls read method to display details that can be added in. i.e title		//	|																	
////			Customer nCustomer = Customer.read();										//	|
////			//adds new customer to the customers array									//	|
////			customers.add(nCustomer);													//	|
////			//Code that will save the details entered on the customer.txt file			//	|
////			//writeRecordsToFile();														//	|
////		}																				//	|
////------------------------------------------------------------------------------------------|
//		//Method for saving information to a file				
//		
//		
//		
////		public void writeRecordsToFile()												//	|
////		{																				//	|
////			//Attempts to create file...												//	|
////			try																			//	|
////			{																			//	|
////				FileOutputStream fileStream = new FileOutputStream(FILENAME);			//	|
////				ObjectOutputStream os = new ObjectOutputStream(fileStream);				//	|
////				os.writeObject(customers);												//	|
////				os.close();																//	|
////			}																			//	|
////			catch(FileNotFoundException fNFE)											//	|
////			//...display message if an error occurs										//	|
////			{																			//	|
////				System.out.println("Cannot create file to store customers");			//	|
////			}																			//	|
////			catch(Exception e)															//	|
////			{																			//	|
////				System.out.println(e.getMessage());										//	|
////			}																			//	|
////		}																				//	|
////------------------------------------------------------------------------------------------|
////		//Method to try read info from newly created file								//	|
////		public void readRecordsFromFile()												//	|
////		{																				//	|
////			//Attempt to read file....													//	|
////			try																			//	|
////			{																			//	|
////				FileInputStream fis = new FileInputStream(FILENAME);					//	|
////				ObjectInputStream is = new ObjectInputStream(fis);						//	|
////				customers = (ArrayList<Customer>)is.readObject();						//	|
////				is.close();																//	|
////			}																			//	|
////		catch(FileNotFoundException fNFE)												//	|
////		//...if it fails to read file display											//	|
////		{																				//	|
////			System.out.println("Cannot find Customer File");							//	|
////			System.out.println("Maybe try creating a new one by adding a customer?");	//	|
////		}																				//	|
////			catch(Exception e)															//	|
////			{																			//	|
////				System.out.println(e.getMessage());										//	|
////			}																			//	|
////		}																				//	|
////------------------------------------------------------------------------------------------|
//		//Method for listing all the customers currently in the array					//	|
//		public void list()																//	|
//		{																				//	|
//			//If there are no customers or if the file can't be read display			//	|
//			if(customers.isEmpty())														//	|
//				System.out.println("No Customers\n");									//	|
//			else																		//	|
//				for(Customer tempCustomer:customers)									//	|
//				{																		//	|
//					System.out.println(tempCustomer.toString());						//	|
//				}																		//	|
//		}																				//	|
////------------------------------------------------------------------------------------------|	
//		//Method to simply clear the menu. ie cancel the program						//	|
//		public void clear()																//	|
//		{																				//	|
//			customers.clear();															//	|
//		}																				//	|
////------------------------------------------------------------------------------------------|
//		//Method to view an individual user												//	|
//		public Customer view()															//	|
//		{																				//	|
//			Scanner keyIn = new Scanner(System.in);										//	|
//			System.out.println("Please enter the number of your chosen customer: \t");	//	|
//			int customerToView;															//	|
//				try{																	//	|
//					//Receives user input and compares to UID of customers in array		//	|
//						customerToView = keyIn.nextInt();								//	|
//						for(Customer tempCustomer:customers)							//	|
//						{																//	|
//							if(tempCustomer.getNumber() == customerToView)				//	|
//							{															//	|
//								System.out.println(tempCustomer);						//	|
//								return tempCustomer;									//	|
//							}															//	|
//					//If number entered does not match any known customer display		//	|
//							if (tempCustomer.getNumber() != customerToView)				//	|
//							{															//	|
//							System.out.println("There is only "+customers.size()		//	|
//							+" customer(s)\n");											//	|
//							}															//	|
//						}																//	|
//				//if user does not enter a number										//	|
//				}catch(Exception e)														//	|
//				{																		//	|
//					System.out.println("NOT A NUMBER!\n");								//	|					
//				}																		//	|
//				return null;															//	|
//		}																				//	|
////------------------------------------------------------------------------------------------|
//		//Method to delete customer from array											//	|
//		public void delete()															//	|
//		{																				//	|
//			//Call view() to enter in user to be deleted								//	|
//			Customer tempCustomer = view();												//	|
//			// If tempCutomer != null, i.e. it was found then...						//	|
//			if(tempCustomer != null)													//	|
//				// ...remove it from tempCustomer										//	|
//				customers.remove(tempCustomer);	    									//	|
//			//Method called to save removal												//	|
//			//writeRecordsToFile();														//	|
//		}																				//	|
////------------------------------------------------------------------------------------------|
//		//Method to edit customer in array												//	|
//		public void edit()																//	|
//		{																				//	|
//			//Call view() to prompt which user to edit									//	|
//			Customer tempCustomer = view();												//	|
//			if(tempCustomer != null)													//	|
//			{																			//	|
//				int index = customers.indexOf(tempCustomer);							//	|
//				//Display details to be edit											//	|
//				tempCustomer.read();													//	|
//				customers.set(index, tempCustomer);										//	|
//				//Save changes	to customer.txt											//	|
//				//writeRecordsToFile();													//	|	
//			}																			//	|
//		}																				//	|
//}																						//	|
//------------------------------------------------------------------------------------------|
