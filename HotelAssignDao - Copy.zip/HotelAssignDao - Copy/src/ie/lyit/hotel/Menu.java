//----------------------------------------------------------------------------------|
// Connor McCabe - L00114966													//	|
// Computer Security and Digital Forensics										//	|
//Software Implementation Assignment 1 for Maria Boyle							//	|
// 15/11/17																		//	|
package ie.lyit.hotel;															//	|
import java.util.*;																//	|
//----------------------------------------------------------------------------------|
public class Menu {																//	|
	private int option;															//	|
//----------------------------------------------------------------------------------|
	public void display(){														//	|
																				//	|
		System.out.print("\t|-----------------------|\n");						//	|
		System.out.print("\t|     Customer Menu     |\n");						//	|
		System.out.print("\t|-----------------------|\n");						//	|
		System.out.println("\t| 1. Add a Customer     |");						//	|
		System.out.println("\t| 2. List all Customers |");						//	|
		System.out.println("\t| 3. View  an Customer  |");						//	|
		System.out.println("\t| 4. Edit an Customer   |");						//	|
		System.out.println("\t| 5. Delete an Customer |");						//	|
		System.out.println("\t| 6. Quit the Program   |");						//	|
		System.out.print("\t|--------------------------------|\n");				//	|
	}																			//	|
//----------------------------------------------------------------------------------|
	public void readOption(){													//	|
		Scanner kbInt = new Scanner(System.in);									//	|
		do{																		//	|
			try{																//	|
				   System.out.println("\t| Choose an  Option [1|2|3|4|5|6]|");	//	|
				   System.out.print("\t|--------------------------------|");	//	|
				   System.out.print("\n\t");									//	|
				   option=kbInt.nextInt();										//	|
				   																//	|
				   if(option <= 0 || option >= 7)								//	|
					   System.out.println("ERROR! NOT A VALID NUMBER");			//	|
			   }																//	|
			   		catch(InputMismatchException e){							//	|
			   			System.out.println("ERROR! NOT A NUMBER!\n");			//	|
			   }   																//	|
			   kbInt.nextLine();												//	|
		   }  																	//	|
		   			while(option <= 0 && option >=7);							//	|
	}																			//	|
//----------------------------------------------------------------------------------|
	public int getOption()														//	|
	{																			//	|
		return option;															//	|
	}																			//	|
}																				//	|
//----------------------------------------------------------------------------------|