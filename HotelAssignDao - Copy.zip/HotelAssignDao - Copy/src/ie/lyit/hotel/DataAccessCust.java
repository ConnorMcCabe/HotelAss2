package ie.lyit.hotel;

import ie.lyit.serialize.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
// File Access Object
public class DataAccessCust implements DaoCust {
	
	private final static String FILENAME = "customers.txt";
	
	@SuppressWarnings("unchecked")
	@Override
	public  ArrayList<Customer> read()												//	|
	{											
		
		ArrayList<Customer> customers = null;
		//Attempt to read file....													//	|
		try																			//	|
		{																			//	|
			FileInputStream fis = new FileInputStream(FILENAME);					//	|
			ObjectInputStream is = new ObjectInputStream(fis);						//	|
			customers = (ArrayList<Customer>)is.readObject();						//	|
			is.close();																//	|
		}																			//	|
	catch(FileNotFoundException fNFE)												//	|
	//...if it fails to read file display											//	|
	{																				//	|
		System.out.println("Cannot find Customer File");							//	|
		System.out.println("Maybe try creating a new one by adding a customer?");	//	|
	}																				//	|
		catch(Exception e)															//	|
		{																			//	|
			System.out.println(e.getMessage());										//	|
		}											
		
		return customers;
	}
	//Method for saving information to a file										//	|
			public void writeRecordsToFile()//(ArrayList<Customer> customers)												//	|
			{																				//	|
				//Attempts to create file...												//	|
				try																			//	|
				{																			//	|
					FileOutputStream fileStream = new FileOutputStream(FILENAME);			//	|
					ObjectOutputStream os = new ObjectOutputStream(fileStream);				//	|
					os.writeObject(customers);												//	|
					os.close();																//	|
				}																			//	|
				catch(FileNotFoundException fNFE)											//	|
				//...display message if an error occurs										//	|
				{																			//	|
					System.out.println("Cannot create file to store customers");			//	|
				}																			//	|
				catch(Exception e)															//	|
				{																			//	|
					System.out.println(e.getMessage());										//	|
				}																			//	|
			}
			@Override
			public void write(ArrayList<Customer> customers) {
				// TODO Auto-generated method stub
				
			}									
}
