package ie.lyit.hotel;

//INHERITANCE - Employee IS-a person, and CAN-DO Payable methods
public class Employee extends Person implements Payable {
	
	private Date dob;	//Employee has name, address & ohone number from Person
	private Date startDate; //AND dob, startdate, salary & number
	private double salary;
	private int number;
	
	private static int nextNumber=1; 	//static for unique number - starts o
	private final double MAX_SALARY = 150000;
	
	//Default constructor
	// Called when object is created like this ==> Employee eObj = new Employee();
	public Employee() {
		super();
		dob=new Date();
		startDate=new Date();
		startDate=new Date();
		salary=0.0;
		// Set number to static nextNumber before incrementing nextNumber
		number=nextNumber++;
		
	}
	
	//Initialization Constructor
	// Called when object is created like this ==>
	// Employee eObj == new Employee("details")
	// NOTE: for dob and start date, you can either pass in a d,m,y or a date object
	//To show this, I have done dob as d, m ,y and startDate as a date object.
	public Employee(String t, String fN, String sn, String address, String phoneNo,
					int d, int m, int y, Date startDate, double salary){
			//Call super class constructor - Passing parameters rrewuired by person ONLY	
		super(t, fN, sn, address, phoneNo);
		dob=new Date(d,m,y);
		this.startDate=startDate; //set instance variable to parameter
		this.salary=salary; 
		// set number to static nextNumber before incrementing nextNumber
		number = nextNumber++;
		
					}
	
	//OVERRIDING the Person toString() method"
	// Calling Persons toString() method, and adding additional bits
	@Override
	public String toString() {
		return number + " "+ super.toString() + " �"+salary;
	}
	
	//equals() method
	// ==> Called when comparing an object with another object,
	// e.g - if(e1.equals(e2))
	// ==> Probably sufficient to compare customer numbers as they're unique
	@Override
	public boolean equals(Object obj) {
		Employee eObject;
		if (obj instanceof Employee)
			eObject = (Employee)obj;
		else
			return false;
		
		return(this.number==eObject.number);
	}
	
	//Set() and Get() methods
	public void setDOB(Date dob) {
		this.dob=dob;
	}
	
	public Date getDob() {
		return dob;
	}
		
	public void setStartDate(Date startDate) {
		this.startDate=startDate;
	}
	
	public Date getStartDate() {
		return startDate;
	}
	
	public void setSalary(int salary) {
		this.salary=salary;
	}
	
	public double getSalary() {
		return salary;
	}
	
	// You shouldn't be able to setNumber() as it is unique
	// so don't provide a setNumber() method
	public int getNumber() {
		return number;
	}
	
	
	
	@Override
	public double calculateWage(double taxPercentage) {
		// TODO Auto-generated method stub
		//Calculate and return the wage as salary/12 less taxPercentage
		double wage=salary/12;
		wage -= (wage * (taxPercentage/100));
		return wage;
	}

	@Override
	public double incrementSalary(double incrementAmount) {
		// TODO Auto-generated method stub
		//add incrementAmount to, and return the new salary 
		
		salary += incrementAmount;
		
		if(salary > MAX_SALARY)
			salary = MAX_SALARY;
		
		return salary;
	}

}
