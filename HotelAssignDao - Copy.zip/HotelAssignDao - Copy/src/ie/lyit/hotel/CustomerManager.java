package ie.lyit.hotel;

public class CustomerManager {
	
	public void list()																//	|
	{																				//	|
		//If there are no customers or if the file can't be read display			//	|
		if(customers.isEmpty())														//	|
			System.out.println("No Customers\n");									//	|
		else																		//	|
			for(Customer tempCustomer:customers)									//	|
			{																		//	|
				System.out.println(tempCustomer.toString());						//	|
			}																		//	|
	}	
}
