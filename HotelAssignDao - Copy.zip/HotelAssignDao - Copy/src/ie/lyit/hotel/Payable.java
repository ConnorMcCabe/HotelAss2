package ie.lyit.hotel;

public interface Payable {
	public abstract double calculateWage(double taxPercentage);
	//Don't have to put in public abstract
	double incrementSalary(double incrementAmount);
}
