//----------------------------------------------------------------------------------------------------------|
// Connor McCabe - L00114966																			//	|
// Computer Security and Digital Forensics																//	|
//Software Implementation Assignment 1 for Maria Boyle													//	|
// 15/11/17																								//	|
package ie.lyit.hotel;																					//	|
import java.io.Serializable;																			//	|
import java.util.Scanner;																				//	|
import javax.swing.JOptionPane;																			//	|
import ie.lyit.hotel.Customer;																			//	|
//----------------------------------------------------------------------------------------------------------|
public class Customer extends Person implements Serializable{ 											//	|	
	// Customer uses name, address, and phoneNumber from Person											//	|
	protected String emailAddress;    // AND emailAddress												//	|
	protected int number;			    // AND number													//	|
	private static int nextNumber=0;// static for unique number - starts off at 1						//	|
																										//	|
	// Default Constructor																				//	|									
	public Customer(){																					//	|
		super();																						//	|
		emailAddress=null;																				//	|
		//Setting number to nextNumber incremented														//	|
		number=nextNumber++;																			//	|
	}																									//	|
//----------------------------------------------------------------------------------------------------------|
	public Customer(String t, String fN, String sn, String address, 									//	|
			        String pNo, String email){															//	|
		// Using super() to call from person															//	|
		super(t, fN, sn, address, pNo);																	//	|
		// And then initialise Customers own instance variables											//	|
		emailAddress=email;																				//	|
																										//	|
		number=nextNumber++;																			//	|
	}																									//	|
//----------------------------------------------------------------------------------------------------------|														
	// Calling Customer toString() method, and adding additional information							//  |
	@Override																							//  |
	public String toString(){																			//	|
		return (super.toString()  + "\nEmail: " + this.getEmailAddress() + "\nAddress: " 				//	|
				+ this.getAddress()) + "\nUID: " + this.getNumber();									//	|		
	}																									//	|
//----------------------------------------------------------------------------------------------------------|
	// equals() method																					//	|
	@Override																							//	|
	public boolean equals(Object obj){																	//	|
		Customer cObject;																				//	|
		if (obj instanceof Customer)																	//	|
		   cObject = (Customer)obj;																		//	|
		else																							//	|
		   return false;																				//	|																											
	    return(this.number==cObject.number);															//	|
	}																									//	|
//----------------------------------------------------------------------------------------------------------|
	// set EmailAddress																					//	|
	public void setEmailAddress(String emailAddress)													//	|
	{																									//	|
		this.emailAddress=emailAddress;																	//	|
	}																									//	|
//----------------------------------------------------------------------------------------------------------|
	//Get EmailAddress																					//	|
	public String getEmailAddress()																		//	|
	{																									//	|
		return this.emailAddress;																		//	|
	}																									//	|
//----------------------------------------------------------------------------------------------------------|
	// Get Number																						//	|														
	public int getNumber()																				//	|
	{																									//	|
		return number;																					//	|
	}																									//	|
//----------------------------------------------------------------------------------------------------------|
	//Read Method																						//	|
//	public static Customer read(){																		//	|
//																										//	|
//		Customer customers = new Customer();															//	|
//		Scanner readIn = new Scanner(System.in);														//	|	
//		Name name = new Name();																			//	|
//																										//	|
//		//...From here prompt user to enter in....														//	|
//		System.out.println("Enter Customer Details\n");													//	|
//		//...Customer title...																			//	|
//		System.out.println("Enter Title:");																//	|
//		//...receiving input...																			//	|
//		name.setTitle(readIn.nextLine());																//	|
//																										//	|
//		//...Customer First Name...																		//	|
//		System.out.println("Enter First Name");															//	|
//		//...receiving input...																			//	|
//		name.setFirstName(readIn.nextLine());															//	|
//																										//	|
//		//...Customer Surname...																		//	|
//		System.out.println("Enter Surname:");															//	|
//		//...receiving input...																			//	|
//		name.setSurname(readIn.nextLine());																//	|
//																										//	|
//		//...All details entered so far are saved as customer's name so all will display when called...	//	|
//		customers.setName(name);																		//	|
//																										//	|
//		//...Customer Email...																			//	|
//		System.out.println("Enter Email Address:");														//	|
//		//...receiving input...																			//	|
//		customers.setEmailAddress(readIn.nextLine());													//	|
//																										//	|
//		//...Customer Phone Number...																	//	|
//		System.out.println("Enter Phone Number: ");														//	|
//		//...receiving input...																			//	|
//		customers.setPhoneNumber(readIn.nextLine());													//	|
//																										//	|
//		//...Customer Home Address...																	//	|
//		System.out.println("Enter Address: ");															//	|
//		//...receiving input...																			//	|
//		customers.setAddress(readIn.nextLine());														//	|
//																										//	|
//		//...resumes...																					//	|
//		return customers; 																				//	|																									
	}																									//	|
}																										//	|
//----------------------------------------------------------------------------------------------------------|