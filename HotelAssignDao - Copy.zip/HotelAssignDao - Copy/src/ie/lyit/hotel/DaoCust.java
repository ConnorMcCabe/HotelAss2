package ie.lyit.hotel;

import java.util.ArrayList;

public interface DaoCust {
	// DataAccessInterface
	public ArrayList<Customer> read();

	public void write(ArrayList<Customer> customers);
}
